//                            USER DEFINED SETTINGS
//   Set driver type, fonts to be loaded, pins used and SPI control method etc.
//
//   See the User_Setup_Select.h file if you wish to be able to define multiple
//   setups and then easily select which setup file is used by the compiler.
//
//   If this file is edited correctly then all the library example sketches should
//   run without the need to make any more changes for a particular hardware setup!
//   Note that some sketches are designed for a particular TFT pixel width/height

// User defined information reported by "Read_User_Setup" test & diagnostics example
#define USER_SETUP_INFO "ESP32_ILI9488_Setup"

// ##################################################################################
//
// Section 1. Call up the right driver file and any options for it
//
// ##################################################################################

#define ILI9488_DRIVER     // Driver for ILI9488 320x480 display
//#define TFT_WIDTH  320     // Define pixel width for ILI9488
//#define TFT_HEIGHT 480     // Define pixel height for ILI9488

// ##################################################################################
//
// Section 2. Define the pins that are used to interface with the display here
//
// ##################################################################################

// Define pins for ESP32 hardware SPI
#define TFT_MISO  -1       // MISO not used (ILI9488 SDO does not tristate, so leave disconnected)
#define TFT_MOSI  27       // SDI/MOSI pin (D27)
#define TFT_SCLK  26       // SCK pin (D26)
#define TFT_CS    13       // Chip select control pin (D13)
#define TFT_DC    14       // Data Command control pin (D14)
#define TFT_RST   12       // Reset pin (D12)
#define TFT_BL    25       // LED back-light control pin (D25)
#define TFT_BACKLIGHT_ON HIGH  // Backlight ON when HIGH

// Use hardware SPI (VSPI by default on ESP32)
#define SPI_FREQUENCY  27000000  // 27MHz SPI clock, suitable for ILI9488
#define SPI_READ_FREQUENCY  20000000  // SPI read frequency

// ##################################################################################
//
// Section 3. Define the fonts that are to be used here
//
// ##################################################################################

#define LOAD_GLCD   // Font 1: Adafruit 8 pixel font
#define LOAD_FONT2  // Font 2: Small 16 pixel high font
#define LOAD_FONT4  // Font 4: Medium 26 pixel high font
#define LOAD_FONT6  // Font 6: Large 48 pixel font
#define LOAD_FONT7  // Font 7: 7 segment 48 pixel font
#define LOAD_FONT8  // Font 8: Large 75 pixel font
#define LOAD_GFXFF  // FreeFonts: Include access to 48 Adafruit_GFX free fonts
#define SMOOTH_FONT // Enable smooth font rendering (requires SPIFFS)

// ##################################################################################
//
// Section 4. Other options
//
// ##################################################################################

// Comment out to disable SPI transactions if not needed (saves some code size)
// #define SUPPORT_TRANSACTIONS

// Note: ILI9488 does not support TFT_SDA_READ, so it remains commented out
// #define TFT_SDA_READ

// Optional: Uncomment and try one of these if colors are incorrect
// #define TFT_RGB_ORDER TFT_RGB  // Colour order Red-Green-Blue
// #define TFT_RGB_ORDER TFT_BGR  // Colour order Blue-Green-Red

// Optional: Uncomment one if display colors are inverted
// #define TFT_INVERSION_ON
// #define TFT_INVERSION_OFF